package com.pregyapp.pregyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class selectlogin_Activity : AppCompatActivity() {

    lateinit var doctorImage : ImageButton
    lateinit var patientImage: ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selectlogin)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        doctorImage = findViewById<ImageButton>(R.id.doctorImage)
        doctorImage.setOnClickListener {
            val intent = Intent(this, signindoctor_Activity::class.java)
            startActivity(intent)
        }

        patientImage = findViewById<ImageButton>(R.id.patientImage)
        patientImage.setOnClickListener {
            val intent = Intent(this, patientlogin_Activity::class.java)
            startActivity(intent)
            }
    }
}