package com.pregyapp.pregyapp

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class dietplan_Activity : AppCompatActivity() {

    lateinit var normal_btn : TextView
    lateinit var medium_btn : TextView
    lateinit var low_btn : TextView
    lateinit var back_btn : LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dietplan)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        normal_btn = findViewById<TextView>(R.id.normal_btn)
        normal_btn.setOnClickListener {
            val intent = Intent(this, normalpat_Activity::class.java)
            startActivity(intent)
        }

        medium_btn = findViewById<TextView>(R.id.medium_btn)
        medium_btn.setOnClickListener {
            val intent = Intent(this, otherreport_Activity::class.java)
            startActivity(intent)
        }

        low_btn = findViewById<TextView>(R.id.low_btn)
        low_btn.setOnClickListener {
            val intent = Intent(this, otherreport_Activity::class.java)
            startActivity(intent)
        }
        back_btn = findViewById<LinearLayout>(R.id.back_btn)
        back_btn.setOnClickListener {
            finish()
        }
    }
}