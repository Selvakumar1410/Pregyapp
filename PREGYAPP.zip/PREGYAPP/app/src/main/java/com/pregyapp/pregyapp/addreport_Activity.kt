package com.pregyapp.pregyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class addreport_Activity : AppCompatActivity() {

    lateinit var back_btn : LinearLayout
    lateinit var anemia_btn : Button
    lateinit var hyp_btn : Button
    lateinit var other_btn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_addreport)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        back_btn = findViewById<LinearLayout>(R.id.back_btn)
        back_btn.setOnClickListener {
            finish()
        }

        anemia_btn = findViewById<Button>(R.id.anemia_btn)
        anemia_btn.setOnClickListener {
            val intent = Intent(this, anemia_Activity::class.java)
            startActivity(intent)
        }

        hyp_btn = findViewById<Button>(R.id.hyp_btn)
        hyp_btn.setOnClickListener {
            val intent = Intent(this, hypertension_Activity::class.java)
            startActivity(intent)
        }

        other_btn = findViewById<Button>(R.id.other_btn)
        other_btn.setOnClickListener {
            val intent = Intent(this, otherproblem_Activity::class.java)
            startActivity(intent)
        }
    }
}