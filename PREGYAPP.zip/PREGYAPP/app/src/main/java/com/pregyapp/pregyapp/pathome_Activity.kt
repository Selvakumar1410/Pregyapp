package com.pregyapp.pregyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class pathome_Activity : AppCompatActivity() {

    lateinit var report_btn : Button
    lateinit var diet_btn : Button
    lateinit var anemia_btn : TextView
    lateinit var hyp_btn : TextView
    lateinit var other_btn : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pathome)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        report_btn = findViewById<Button>(R.id.report_btn)
        report_btn.setOnClickListener {
            val intent = Intent(this, viewreport_Activity::class.java)
            startActivity(intent)
        }

        diet_btn = findViewById<Button>(R.id.diet_btn)
        diet_btn.setOnClickListener {
            val intent = Intent(this, dietplan_Activity::class.java)
            startActivity(intent)
        }

        anemia_btn = findViewById<TextView>(R.id.anemia_btn)
        anemia_btn.setOnClickListener {
            val intent = Intent(this, anemiareport_Activity::class.java)
            startActivity(intent)
        }

        hyp_btn = findViewById<TextView>(R.id.hyp_btn)
        hyp_btn.setOnClickListener {
            val intent = Intent(this, hypreport_Activity::class.java)
            startActivity(intent)
        }

        other_btn = findViewById<TextView>(R.id.other_btn)
        other_btn.setOnClickListener {
            val intent = Intent(this, otherreport_Activity::class.java)
            startActivity(intent)
        }
    }
}