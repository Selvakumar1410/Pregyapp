package com.pregyapp.pregyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class doctorhome_Activity : AppCompatActivity() {

    lateinit var docprof_btn : ImageButton
    lateinit var anemiapatlist_btn : Button
    lateinit var hyppatlist_btn : Button
    lateinit var genpatlist_btn : Button
    lateinit var search_btn : LinearLayout
    lateinit var addpatient_btn : ImageButton
    lateinit var setting_btn : ImageButton
    lateinit var report_btn : LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_doctorhome)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        docprof_btn = findViewById<ImageButton>(R.id.docprof_btn)
        docprof_btn.setOnClickListener {
            val intent = Intent(this, doctorprof_Activity::class.java)
            startActivity(intent)
        }

        anemiapatlist_btn = findViewById<Button>(R.id.anemiapatlist_btn)
        anemiapatlist_btn.setOnClickListener {
            val intent = Intent(this, anemiapatlist_Activity::class.java)
            startActivity(intent)
        }

        hyppatlist_btn = findViewById<Button>(R.id.hyppatlist_btn)
        hyppatlist_btn.setOnClickListener {
            val intent = Intent(this, hyppatlist_Activity::class.java)
            startActivity(intent)
        }

        genpatlist_btn = findViewById<Button>(R.id.genpatlist_btn)
        genpatlist_btn.setOnClickListener {
            val intent = Intent(this, genpatlist_Activity::class.java)
            startActivity(intent)
        }

        search_btn = findViewById<LinearLayout>(R.id.search_btn)
        search_btn.setOnClickListener {
            val intent = Intent(this, patrec_Activity::class.java)
            startActivity(intent)
        }

        addpatient_btn = findViewById<ImageButton>(R.id.addpatient_btn)
        addpatient_btn.setOnClickListener {
            val intent = Intent(this, addpatients_Activity::class.java)
            startActivity(intent)
        }

        setting_btn = findViewById<ImageButton>(R.id.setting_btn)
        setting_btn.setOnClickListener {
            val intent = Intent(this, docset_Activity::class.java)
            startActivity(intent)
        }

        report_btn = findViewById<LinearLayout>(R.id.report_btn)
        report_btn.setOnClickListener {
            val intent = Intent(this, report_Activity::class.java)
            startActivity(intent)
        }

    }
}